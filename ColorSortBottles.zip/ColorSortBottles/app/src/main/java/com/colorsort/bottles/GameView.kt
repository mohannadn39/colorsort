package com.colorsort.bottles

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.ceil
import kotlin.math.min

@Suppress("DEPRECATION")
class GameView(context: Context) : View(context) {

    private class Layer(val color: Int, val frac: Float)

    private class Anim(val from: Int, val to: Int, val move: Move) {
        var t = 0f
    }

    private val palette = intArrayOf(
        0xFFE53935.toInt(), // red
        0xFF1E88E5.toInt(), // blue
        0xFF43A047.toInt(), // green
        0xFFFDD835.toInt(), // yellow
        0xFFFB8C00.toInt(), // orange
        0xFF8E24AA.toInt(), // purple
        0xFF00ACC1.toInt(), // cyan
        0xFFEC407A.toInt(), // pink
        0xFF6D4C41.toInt(), // brown
        0xFFC0CA33.toInt(), // lime
        0xFF5C6BC0.toInt(), // indigo
        0xFFB0BEC5.toInt()  // grey
    )

    private val prefs = context.getSharedPreferences("colorsort", Context.MODE_PRIVATE)
    private val density = resources.displayMetrics.density
    private fun dp(v: Float) = v * density

    private var level = prefs.getInt("level", 1).coerceAtLeast(1)
    private var game = LevelGenerator.generate(level)
    private var selected = -1
    private var solved = false
    private var anim: Anim? = null

    private var insetTop = 0f
    private var insetBottom = 0f

    private var bottleRects: List<RectF> = emptyList()
    private val btnUndo = RectF()
    private val btnRestart = RectF()
    private val btnAdd = RectF()

    private val bgPaint = Paint()
    private val glassPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x22FFFFFF }
    private val outlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0xCCFFFFFF.toInt()
        strokeWidth = dp(2.5f)
    }
    private val shinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x40FFFFFF }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val separatorPaint = Paint().apply { color = 0x33000000 }
    private val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt()
        textSize = dp(30f)
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }
    private val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xB3FFFFFF.toInt()
        textSize = dp(14f)
        textAlign = Paint.Align.CENTER
    }
    private val btnPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val btnTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt()
        textSize = dp(16f)
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }
    private val dimPaint = Paint().apply { color = 0xB3000000.toInt() }
    private val panelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF22336B.toInt() }
    private val tmpPath = Path()

    init {
        setOnApplyWindowInsetsListener { _, insets ->
            insetTop = insets.systemWindowInsetTop.toFloat()
            insetBottom = insets.systemWindowInsetBottom.toFloat()
            layoutBoard()
            invalidate()
            insets
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        requestApplyInsets()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        bgPaint.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            0xFF1B2A5C.toInt(), 0xFF0B1230.toInt(), Shader.TileMode.CLAMP
        )
        layoutBoard()
    }

    // ---------------------------------------------------------------- layout

    private fun layoutBoard() {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w == 0f || h == 0f) return

        val n = game.bottles.size
        val rows = if (n <= 5) 1 else 2
        val cols = ceil(n / rows.toFloat()).toInt()
        val top = insetTop + dp(96f)
        val bottom = h - insetBottom - dp(110f)
        val cellW = (w - dp(24f)) / cols
        val cellH = (bottom - top) / rows
        val bw = min(cellW * 0.64f, dp(66f))
        val bh = min(cellH * 0.84f, bw * 3.7f)

        val list = ArrayList<RectF>(n)
        for (i in 0 until n) {
            val r = i / cols
            val c = i % cols
            val inRow = min(cols, n - r * cols)
            val startX = (w - inRow * cellW) / 2f
            val cx = startX + cellW * (c + 0.5f)
            val cy = top + cellH * (r + 0.5f)
            list.add(RectF(cx - bw / 2f, cy - bh / 2f, cx + bw / 2f, cy + bh / 2f))
        }
        bottleRects = list

        val gap = dp(12f)
        val bwid = (w - gap * 4) / 3f
        val bhgt = dp(52f)
        val by = h - insetBottom - dp(28f) - bhgt
        btnUndo.set(gap, by, gap + bwid, by + bhgt)
        btnRestart.set(gap * 2 + bwid, by, gap * 2 + bwid * 2, by + bhgt)
        btnAdd.set(gap * 3 + bwid * 2, by, gap * 3 + bwid * 3, by + bhgt)
    }

    // --------------------------------------------------------------- drawing

    private fun ease(x: Float): Float {
        val t = x.coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    /** 0..1: how far the source bottle has travelled to the target and tilted. */
    private fun moveProgress(t: Float): Float = when {
        t < 0.25f -> ease(t / 0.25f)
        t > 0.75f -> ease((1f - t) / 0.25f)
        else -> 1f
    }

    /** 0..1: how much liquid has been transferred. */
    private fun pourProgress(t: Float): Float = ((t - 0.25f) / 0.5f).coerceIn(0f, 1f)

    private fun layersFor(i: Int, a: Anim?): List<Layer> {
        val b = game.bottles[i]
        val p = if (a != null) pourProgress(a.t) else 1f
        val out = ArrayList<Layer>(b.size + 4)
        for ((idx, c) in b.withIndex()) {
            val f = if (a != null && i == a.to && idx >= b.size - a.move.count) p else 1f
            out.add(Layer(c, f))
        }
        if (a != null && i == a.from) {
            repeat(a.move.count) { out.add(Layer(a.move.color, 1f - p)) }
        }
        return out
    }

    private fun bottlePath(r: RectF): Path {
        tmpPath.reset()
        val rt = dp(5f)
        val rb = r.width() * 0.42f
        tmpPath.addRoundRect(r, floatArrayOf(rt, rt, rt, rt, rb, rb, rb, rb), Path.Direction.CW)
        return tmpPath
    }

    private fun drawBottle(canvas: Canvas, r: RectF, layers: List<Layer>, doneColor: Int) {
        val path = bottlePath(r)
        canvas.drawPath(path, glassPaint)

        canvas.save()
        canvas.clipPath(path)
        val pad = dp(4f)
        val layerH = (r.height() - pad * 2) / game.capacity
        var y = r.bottom - pad
        for (l in layers) {
            val hh = layerH * l.frac
            if (hh <= 0f) continue
            fillPaint.color = palette[l.color % palette.size]
            canvas.drawRect(r.left, y - hh, r.right, y, fillPaint)
            canvas.drawRect(r.left, y - hh, r.right, y - hh + dp(1f), separatorPaint)
            y -= hh
        }
        canvas.restore()

        canvas.drawRoundRect(
            r.left + r.width() * 0.18f, r.top + r.height() * 0.12f,
            r.left + r.width() * 0.28f, r.bottom - r.height() * 0.2f,
            dp(3f), dp(3f), shinePaint
        )
        canvas.drawPath(path, outlinePaint)

        if (doneColor >= 0) {
            fillPaint.color = palette[doneColor % palette.size]
            canvas.drawRoundRect(
                r.centerX() - r.width() * 0.32f, r.top - dp(9f),
                r.centerX() + r.width() * 0.32f, r.top - dp(2f),
                dp(3f), dp(3f), fillPaint
            )
        }
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        canvas.drawText("Level $level", width / 2f, insetTop + dp(48f), titlePaint)
        val sub = if (level == 1 && game.history.isEmpty())
            "Tap a bottle, then tap another to pour"
        else
            "Moves: ${game.history.size}"
        canvas.drawText(sub, width / 2f, insetTop + dp(74f), subPaint)

        val a = anim
        for (i in bottleRects.indices) {
            if (a != null && i == a.from) continue
            val rect = RectF(bottleRects[i])
            if (i == selected && a == null) rect.offset(0f, -rect.height() * LIFT)
            val done = game.isBottleDone(i) && !(a != null && a.to == i)
            drawBottle(canvas, rect, layersFor(i, a), if (done) game.topColor(i) else -1)
        }
        if (a != null) drawPour(canvas, a)

        drawButton(canvas, btnUndo, "Undo", game.history.isNotEmpty() && anim == null)
        drawButton(canvas, btnRestart, "Restart", anim == null)
        drawButton(canvas, btnAdd, "+ Bottle", !game.extraUsed && anim == null)

        if (solved && anim == null) drawWinOverlay(canvas)
    }

    private fun drawPour(canvas: Canvas, a: Anim) {
        val src = RectF(bottleRects[a.from])
        src.offset(0f, -src.height() * LIFT) // it was lifted when selected
        val dst = bottleRects[a.to]
        val bw = src.width()
        val dir = if (dst.centerX() >= src.centerX()) 1f else -1f
        val m = moveProgress(a.t)
        val p = pourProgress(a.t)

        val lipX = dst.centerX()
        val lipY = dst.top - bw * 0.7f
        val targetCx = lipX - dir * bw / 2f
        val dx = (targetCx - src.centerX()) * m
        val dy = (lipY - src.top) * m

        // falling stream
        if (p > 0.02f && p < 0.98f) {
            val dstLayerH = (dst.height() - dp(8f)) / game.capacity
            val levelNow = game.bottles[a.to].size - a.move.count + a.move.count * p
            val surface = dst.bottom - dp(4f) - dstLayerH * levelNow
            fillPaint.color = palette[a.move.color % palette.size]
            canvas.drawRect(lipX - dp(2.5f), lipY, lipX + dp(2.5f), surface, fillPaint)
        }

        canvas.save()
        canvas.translate(dx, dy)
        canvas.rotate(dir * 55f * m, src.centerX() + dir * bw / 2f, src.top)
        drawBottle(canvas, src, layersFor(a.from, a), -1)
        canvas.restore()
    }

    private fun drawButton(canvas: Canvas, r: RectF, label: String, enabled: Boolean) {
        btnPaint.color = if (enabled) 0xFF3A5BC7.toInt() else 0x553A5BC7
        canvas.drawRoundRect(r, dp(14f), dp(14f), btnPaint)
        btnTextPaint.alpha = if (enabled) 255 else 110
        val fm = btnTextPaint.fontMetrics
        canvas.drawText(label, r.centerX(), r.centerY() - (fm.ascent + fm.descent) / 2f, btnTextPaint)
    }

    private fun drawWinOverlay(canvas: Canvas) {
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dimPaint)
        val pw = width - dp(64f)
        val ph = dp(170f)
        val panel = RectF(
            (width - pw) / 2f, (height - ph) / 2f,
            (width + pw) / 2f, (height + ph) / 2f
        )
        canvas.drawRoundRect(panel, dp(24f), dp(24f), panelPaint)
        canvas.drawText("Level $level complete!", panel.centerX(), panel.top + dp(62f), titlePaint)
        canvas.drawText("Moves: ${game.history.size}", panel.centerX(), panel.top + dp(94f), subPaint)
        btnTextPaint.alpha = 255
        canvas.drawText("Tap to continue", panel.centerX(), panel.top + dp(136f), btnTextPaint)
    }

    // ----------------------------------------------------------------- input

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> return true
            MotionEvent.ACTION_UP -> {
                performClick()
                handleTap(e.x, e.y)
                return true
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun hitBottle(x: Float, y: Float): Int {
        for (i in bottleRects.indices) {
            val r = RectF(bottleRects[i])
            r.inset(-dp(8f), -dp(14f))
            if (r.contains(x, y)) return i
        }
        return -1
    }

    private fun handleTap(x: Float, y: Float) {
        if (anim != null) return
        if (solved) {
            nextLevel()
            return
        }
        when {
            btnUndo.contains(x, y) -> {
                if (game.undo() != null) selected = -1
            }
            btnRestart.contains(x, y) -> {
                game.reset()
                selected = -1
                layoutBoard()
            }
            btnAdd.contains(x, y) -> {
                if (game.addBottle()) layoutBoard()
            }
            else -> {
                val i = hitBottle(x, y)
                if (i >= 0) onBottleTapped(i) else selected = -1
            }
        }
        invalidate()
    }

    private fun onBottleTapped(i: Int) {
        val sel = selected
        when {
            sel == -1 -> if (game.bottles[i].isNotEmpty()) selected = i
            sel == i -> selected = -1
            game.canPour(sel, i) -> startPour(sel, i)
            else -> selected = if (game.bottles[i].isNotEmpty()) i else -1
        }
    }

    private fun startPour(from: Int, to: Int) {
        val move = game.pour(from, to) ?: return
        selected = -1
        val a = Anim(from, to, move)
        anim = a
        performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 650L + 90L * move.count
            addUpdateListener {
                a.t = it.animatedValue as Float
                invalidate()
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    anim = null
                    afterMove()
                }
            })
            start()
        }
    }

    private fun afterMove() {
        if (game.isSolved()) {
            solved = true
            prefs.edit().putInt("level", level + 1).apply()
        }
        invalidate()
    }

    private fun nextLevel() {
        level++
        game = LevelGenerator.generate(level)
        solved = false
        selected = -1
        layoutBoard()
        invalidate()
    }

    private companion object {
        const val LIFT = 0.14f
    }
}
