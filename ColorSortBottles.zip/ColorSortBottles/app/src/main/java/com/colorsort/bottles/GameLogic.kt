package com.colorsort.bottles

import kotlin.math.min
import kotlin.random.Random

/** One pour: [count] layers of [color] moved from bottle [from] to bottle [to]. */
class Move(val from: Int, val to: Int, val count: Int, val color: Int)

/**
 * Pure game state (no Android dependencies, so it can be unit-tested on the JVM).
 * Each bottle is a list of colour ids ordered bottom -> top.
 */
class Game(val capacity: Int, initial: List<List<Int>>) {

    private val start: List<List<Int>> = initial.map { it.toList() }

    val bottles: MutableList<MutableList<Int>> =
        start.map { it.toMutableList() }.toMutableList()

    val history = ArrayList<Move>()

    var extraUsed = false
        private set

    fun topColor(i: Int): Int = bottles[i].lastOrNull() ?: -1

    /** Number of identical layers sitting on top of bottle [i]. */
    fun topRun(i: Int): Int {
        val b = bottles[i]
        if (b.isEmpty()) return 0
        val c = b.last()
        var n = 0
        while (n < b.size && b[b.size - 1 - n] == c) n++
        return n
    }

    fun canPour(from: Int, to: Int): Boolean {
        if (from == to) return false
        val src = bottles[from]
        val dst = bottles[to]
        if (src.isEmpty() || dst.size >= capacity) return false
        return dst.isEmpty() || dst.last() == src.last()
    }

    fun pour(from: Int, to: Int): Move? {
        if (!canPour(from, to)) return null
        val color = bottles[from].last()
        val n = min(topRun(from), capacity - bottles[to].size)
        repeat(n) {
            bottles[from].removeAt(bottles[from].size - 1)
            bottles[to].add(color)
        }
        val m = Move(from, to, n, color)
        history.add(m)
        return m
    }

    fun undo(): Move? {
        if (history.isEmpty()) return null
        val m = history.removeAt(history.size - 1)
        repeat(m.count) {
            bottles[m.to].removeAt(bottles[m.to].size - 1)
            bottles[m.from].add(m.color)
        }
        return m
    }

    /** One extra empty bottle per level. */
    fun addBottle(): Boolean {
        if (extraUsed) return false
        bottles.add(ArrayList())
        extraUsed = true
        return true
    }

    fun reset() {
        bottles.clear()
        start.forEach { bottles.add(it.toMutableList()) }
        history.clear()
        extraUsed = false
    }

    fun isBottleDone(i: Int): Boolean {
        val b = bottles[i]
        return b.size == capacity && b.all { it == b[0] }
    }

    fun isSolved(): Boolean = bottles.indices.all { bottles[it].isEmpty() || isBottleDone(it) }
}

/** Depth-first search with a node budget; used to guarantee generated levels are winnable. */
object Solver {
    fun solvable(start: List<List<Int>>, capacity: Int, nodeLimit: Int = 30000): Boolean {
        val seen = HashSet<String>()
        val stack = ArrayList<List<List<Int>>>()
        stack.add(start)
        seen.add(key(start))
        var nodes = 0
        while (stack.isNotEmpty() && nodes < nodeLimit) {
            val s = stack.removeAt(stack.size - 1)
            nodes++
            if (isSolved(s, capacity)) return true
            for (from in s.indices) {
                val src = s[from]
                if (src.isEmpty()) continue
                val c = src.last()
                var run = 0
                while (run < src.size && src[src.size - 1 - run] == c) run++
                val srcUniform = run == src.size
                for (to in s.indices) {
                    if (to == from) continue
                    val dst = s[to]
                    if (dst.size >= capacity) continue
                    if (dst.isEmpty()) {
                        if (srcUniform) continue // pointless: moving a pure stack to an empty bottle
                    } else if (dst.last() != c) continue
                    val n = min(run, capacity - dst.size)
                    val next = s.mapIndexed { i, b ->
                        when (i) {
                            from -> b.subList(0, b.size - n).toList()
                            to -> b + List(n) { c }
                            else -> b
                        }
                    }
                    if (seen.add(key(next))) stack.add(next)
                }
            }
        }
        return false
    }

    fun isSolved(s: List<List<Int>>, capacity: Int): Boolean =
        s.all { it.isEmpty() || (it.size == capacity && it.all { c -> c == it[0] }) }

    private fun key(s: List<List<Int>>): String =
        s.map { it.joinToString(",") }.sorted().joinToString("|")
}

object LevelGenerator {
    const val CAPACITY = 4
    const val MAX_COLORS = 12
    private const val EMPTY_BOTTLES = 2

    fun colorsFor(level: Int): Int = min(3 + (level - 1) / 2, MAX_COLORS)

    fun generate(level: Int, rng: Random = Random.Default): Game {
        val colors = colorsFor(level)
        var last: List<List<Int>> = emptyList()
        repeat(40) {
            val segments = (0 until colors).flatMap { c -> List(CAPACITY) { c } }.shuffled(rng)
            val bottles = segments.chunked(CAPACITY).toMutableList()
            repeat(EMPTY_BOTTLES) { bottles.add(emptyList()) }
            last = bottles
            val alreadyDone = bottles.any { it.size == CAPACITY && it.all { c -> c == it[0] } }
            if (!alreadyDone && Solver.solvable(bottles, CAPACITY)) return Game(CAPACITY, bottles)
        }
        return Game(CAPACITY, last)
    }
}
